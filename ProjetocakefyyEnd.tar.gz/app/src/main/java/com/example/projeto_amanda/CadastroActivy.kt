package com.example.projeto_amanda

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.auth.FirebaseAuth

class CadastroActivity : AppCompatActivity() {

    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_cadstro)

        auth = FirebaseAuth.getInstance()

        val nome = findViewById<EditText>(R.id.etNome)
        val email = findViewById<EditText>(R.id.etEmail)
        val usuario = findViewById<EditText>(R.id.etUsuario)
        val senha = findViewById<EditText>(R.id.etSenha)
        val confirmarSenha = findViewById<EditText>(R.id.etConfirmarSenha)
        val btnCadastrar = findViewById<Button>(R.id.btnCadastrar)

        btnCadastrar.setOnClickListener {

            val emailTexto = email.text.toString().trim()
            val senhaTexto = senha.text.toString()
            val confirmarTexto = confirmarSenha.text.toString()

            if (emailTexto.isEmpty() || senhaTexto.isEmpty()) {
                Toast.makeText(this, "Preencha e-mail e senha", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            if (senhaTexto != confirmarTexto) {
                Toast.makeText(this, "As senhas não são iguais", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            auth.createUserWithEmailAndPassword(emailTexto, senhaTexto)
                .addOnCompleteListener(this) { task ->

                    if (task.isSuccessful) {

                        Toast.makeText(
                            this,
                            "Conta criada com sucesso!",
                            Toast.LENGTH_SHORT
                        ).show()

                        val intent = Intent(this, MainActivity::class.java)
                        startActivity(intent)
                        finish()

                    } else {
                        Toast.makeText(
                            this,
                            "Erro: ${task.exception?.message}",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
        }
    }
}