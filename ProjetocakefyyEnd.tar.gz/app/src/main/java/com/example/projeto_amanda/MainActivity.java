package com.example.projeto_amanda;

import android.os.Bundle;
import android.view.Menu;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;

import com.example.projeto_amanda.HomeFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        bottomNavigationView = findViewById(R.id.bottomnavigationView);

        getSupportFragmentManager().beginTransaction().replace(R.id.fragment, new ConfigFragment()).commit();

        bottomNavigationView.setOnItemSelectedListener(menuItem -> {
            Fragment seletedFragment = null;

            if (menuItem.getItemId() == R.id.casa){
                seletedFragment = new HomeFragment();
            } else if (menuItem.getItemId() == R.id.pesquisa) {
                seletedFragment = new SearchFragment();
            } else if (menuItem.getItemId() == R.id.config) {
                seletedFragment = new ConfigFragment();
            } else if (menuItem.getItemId() == R.id.perfil) {
                seletedFragment = new ProfileFragment();
            }

            if (seletedFragment != null){
                getSupportFragmentManager().beginTransaction().replace(R.id.fragment, seletedFragment).commit();
            }
            return true;
        });
    }
}